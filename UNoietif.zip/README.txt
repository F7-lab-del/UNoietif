===============================================
|     | |\      |  _____  .  ____ ____ .  ____
|     | |  \    | |     | | |      |   | |
|     | |    \  | |     | | |____  |   | |____
|_____| |      \| |_____| | |____  |   | | 
===============================================
Desenvolvido por: F7

Descri��o: UNoietif � uma ferramenta de extenss�o .bat projetado para parar/neutralizar um dos, se n�o, o malware mais destruidor de todos os tempos o oietif, um vir�s extremamente perigoso que consegue, usando permiss�es de baixo n�vel, apagar o CMOS, sobrescrever a UEFI/BIOS, sobrescrever o HD e modificar a MBR para uma mensagem ecrita: "you just got OIETIFed. Game over". Tudo isso de forma quase instantanea, ou seja,se esse .bat for executado, ap�s 2 a 4 segundos, o computador crasha e apaga o Windows e aparece uma MBR diferente, e ap�s isso a maquina acaba ficando inoperante devido aos danos causados aos componentes de hardware citados anteriormente, por isso, que na opini�o do autor do UNoietif ele � o mais destrutivo de todos os tempo, porque al�m disso, este malware n�o possui nenhuma ferramenta de combate conhecida, foi a� que o autor, ap�s muitos estudos do codigo fonte desse malware desenvolver uma ferramenta .bat que pudesse parar instantaneamente o vir�s e garantir que a m�quina n�o se torne inoperante.

O que ele faz: Ao executar o .bat, ele cria um script de monitoramento "wscript.exe" que por sua vez, roda em segundo plano na maquina do usu�rio, que oferece prote��o em dupla camada, ele monitora monitora a pasta %appdata% local esse que o malware atua, dropando 2 arquivos o "x.js" e o "s.exe" que s�o responsaveis pela destrui��o da maquina, o .bat foi projetado para apagar-los rapidamente atrav�s de um loop 100 milisegundos, fazendo com que o arquivo mal-intencionado n�o consiga usar o x.js para decodificar o s.exe que � o executavel que destroi a m�quina. E ao apagar ele exibe uma rapida mensagem escrita: "you were not OIETIFed. Continue the game and relax" uma forma de refer�ncia a MBR modificada do oietif, logo ap�s a caixa de mensagem, o computador permanece operante e sem danos.

IMPORTANTE!: se voc� quiser testar esta ferramenta contra o virus real, execute ele primeiro!

- Se voc� fez o dowload, te agrade�o pela sua colabora��o. ;)


